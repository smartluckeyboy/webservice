springmvc_googlechart
=====================

Its demonstrate how to use google chart with Spring MVC 3.2 Applications.